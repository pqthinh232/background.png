#include <iostream>

using namespace std;

struct Node {
    int val;
    Node* left;
    Node* right;
    Node(int value) : val(value), left(nullptr), right(nullptr) {}
};

void insert(Node* &root, int value) {
    if (root == nullptr) {
        Node* node = new Node(value);
        root = node;
        return;
    }
    if (root->val == value)
        return;
    if (value < root->val)
        insert(root->left, value);
    else    
        insert(root->right, value);
}

int height(Node* root) {
    if (root == nullptr)
        return -1;
    return 1 + max(height(root->left), height(root->right));
}

Node* createTree(int a[], int n) {
    Node* root = nullptr;
    for (int i = 0; i < n; i++)
        insert(root, a[i]);
    return root;
}

bool allLeavesHaveSameDepth(Node* root) {
    if (root == nullptr)
        return true;
    if ((root->left == nullptr) ^ (root->right == nullptr))
        return true;
    if (height(root->left) != height(root->right))
        return false;
    return allLeavesHaveSameDepth(root->left) && allLeavesHaveSameDepth(root->right);
}

void destroy(Node* &root) {
    if (root == nullptr)
        return;
    destroy(root->left);
    destroy(root->right);
    delete root;
    root = nullptr;
}

int main()
{
    int a[] = {5, 2, 0, 1, 4, 3, 8, 7, 6, 9, 10};
    int n = sizeof(a) / sizeof(int);

    Node* root = createTree(a, n);
    if (allLeavesHaveSameDepth(root))
        cout << "All leaves of a AVL tree have the same depth!\n";
    else
        cout << "All leaves of a AVL tree have not the same depth!\n";
    destroy(root);
    return 0;
}