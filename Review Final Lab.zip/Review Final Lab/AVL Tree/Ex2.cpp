#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>

using namespace std;

struct Node {
    int val;
    Node* left;
    Node* right;
    Node(int value) : val(value), left(nullptr), right(nullptr) {}
};

void insert(Node* &root, int value) {
    if (root == nullptr) {
        Node* node = new Node(value);
        root = node;
        return;
    }
    if (root->val == value)
        return;
    if (value < root->val)
        insert(root->left, value);
    else    
        insert(root->right, value);
}

int height(Node* root) {
    if (root == nullptr)
        return -1;
    return 1 + max(height(root->left), height(root->right));
}

void destroy(Node* &root) {
    if (root == nullptr)
        return;
    destroy(root->left);
    destroy(root->right);
    delete root;
    root = nullptr;
}

void input(vector<Node*> &trees, int &n, string inputFile) {
    ifstream ifs;
    ifs.open(inputFile);
    if (!ifs) {
        cout << "Cant open file!";
        ifs.close();
        return;
    }
    ifs >> n;
    ifs.ignore();
    for (int i = 0; i < n; i++) {
        Node* tree = nullptr;
        string s;
        getline(ifs, s);
        stringstream ss(s);
        int val;
        while (ss >> val) {
            insert(tree, val);
        }
        trees.push_back(tree);
    }
    ifs.close();
}

int balanceValue(Node* root) {
    return height(root->left) - height(root->right);
}

bool isAVL(Node* root) {
    if (root == nullptr)
        return true;
    int balanceVal = balanceValue(root);
    if (balanceVal > 1 || balanceVal < -1)
        return false;
    return isAVL(root->left) && isAVL(root->right);
}

int main()
{
    int n;
    vector<Node*> trees;

    input(trees, n, "input.txt");
    ofstream ofs;
    ofs.open("output.txt");
    for (auto tree : trees) {
        if (isAVL(tree))
            ofs << "yes\n";
        else    
            ofs << "no\n";
    }
    ofs.close();
    for (auto root : trees)
        destroy(root);
    return 0;
}