#include <iostream>

using namespace std;

struct Node {
    int value;
    Node *left, *right;
    Node(int val) : value(val), left(nullptr), right(nullptr) {}
};

void initialize(Node* &root) {
    root = nullptr;
}

int height(Node* root) {
    if (root == nullptr)
        return -1;
    return 1 + max(height(root->left), height(root->right));
}

int balanceValue(Node* root) {
    return height(root->left) - height(root->right);
}

Node* singleRotateLeft(Node* &root) {
    if (root == nullptr)
        return nullptr;
    Node* newRoot = root->right;
    root->right = newRoot->left;
    newRoot->left = root;
    return newRoot;
}

Node* singleRotateRight(Node* &root) {
    if (root == nullptr)
        return nullptr;
    Node* newRoot = root->left;
    root->left = newRoot->right;
    newRoot->right = root;
    return newRoot;
}

Node* doubleRotateLeft(Node* &root) {
    if (root == nullptr)
        return nullptr;
    root->right = singleRotateRight(root->right);
    root = singleRotateLeft(root);
    return root;
}

Node* doubleRotateRight(Node* &root) {
    if (root == nullptr)
        return nullptr;
    root->left = singleRotateLeft(root->left);
    root = singleRotateRight(root);
    return root;
}

Node* balance(Node* &root) {
    if (root == nullptr)
        return nullptr;
    int banlanceVal = balanceValue(root);
    if (banlanceVal > 1 && balanceValue(root->left) >= 0) 
        return singleRotateRight(root);
    if (banlanceVal < -1 && balanceValue(root->left) < 0) 
        return singleRotateLeft(root);
    if (banlanceVal > 1 && balanceValue(root->right) >= 0) 
        return doubleRotateRight(root);
    if (banlanceVal < -1 && balanceValue(root->right) < 0) 
        return doubleRotateLeft(root);
    return root;
}

void insertNode(Node *&root, int val) {
    if (root == nullptr) {
        root = new Node(val);
        return;
    }
    if (val == root->value) 
        return;
    if (val < root->value) {
        insertNode(root->left, val);
        root = balance(root);
    }
    else {
        insertNode(root->right, val);
        root = balance(root);
    }
}

void NLR(Node*root) {
    if (root == nullptr)
        return;
    cout << root->value << " ";
    NLR(root->left);
    NLR(root->right);
}

void LNR(Node*root) {
    if (root == nullptr)
        return;
    LNR(root->left);
    cout << root->value << " ";
    LNR(root->right);
}

void LRN(Node*root) {
    if (root == nullptr)
        return;
    LRN(root->left);
    LRN(root->right);
    cout << root->value << " ";
}

void remove(Node *&root, int val) {
    if (root == nullptr)
        return;
    if (val < root->value)
        remove(root->left, val);
    else
    if (val > root->value)
        remove(root->right, val);
    else {
        if (root->left == nullptr) {
            Node* tmp = root;
            root = root->right;
            delete tmp;
        } else
        if (root->right == nullptr) {
            Node* tmp = root;
            root = root->left;
            delete tmp;
        } else {
            Node* tmp = root->right, *cur = tmp;
            while (cur->left != nullptr)
                cur = cur->left;
            cur->left = root->left;
            delete root;
            root = tmp;
            return;
        }
    }
}

void deleteNode(Node *&root, int val) {
    remove(root, val);
    root = balance(root);
}

bool identify(Node* root, int val) {
    if (root == nullptr)
        return false;
    if (root->value == val)
        return true;
    if (root->value < val)
        return identify(root->right, val);
    return identify(root->left, val);
}

int main()
{
    int a[7] = {12, 8, 5, 4, 11, 18, 17};
    int n = sizeof(a) / sizeof(int);

    Node* root;
    initialize(root);
    for (int i = 0; i < n; i++)
        insertNode(root, a[i]);

    insertNode(root, 6);
    insertNode(root, 2);
    deleteNode(root, 8);

    cout << "NLR: ";
    NLR(root);
    cout << endl << endl;

    cout << "LNR: ";
    LNR(root);
    cout << endl << endl;

    cout << "LRN: ";
    LRN(root);
    cout << endl << endl;

    int val = 12;

    if (identify(root, val))
        cout << val << " exist in AVL tree!\n\n";
    else
        cout << val << " non-exist in AVL tree!\n\n";

    val = 8;
    if (identify(root, val))
        cout << val << " exist in AVL tree!\n\n";
    else
        cout << val << " non-exist in AVL tree!\n\n";

    return 0;
}