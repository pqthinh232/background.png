#include <iostream>
#include <vector>

using namespace std;

struct Node {
    int val;
    Node *left, *right;
    Node(int value) : val(value), left(nullptr), right(nullptr) {}
};

Node* createNode(int value) {
    return new Node(value);
}

void NLR(Node*root) {
    if (root == nullptr)
        return;
    cout << root->val << " ";
    NLR(root->left);
    NLR(root->right);
}

void LNR(Node*root) {
    if (root == nullptr)
        return;
    LNR(root->left);
    cout << root->val << " ";
    LNR(root->right);
}

void LRN(Node*root) {
    if (root == nullptr)
        return;
    LRN(root->left);
    LRN(root->right);
    cout << root->val << " ";
}

void LevelOrder(Node *root) {
    if (root == nullptr)
        return;
    vector<Node*> cur;
    cur.push_back(root);
    int i = 0, size = cur.size();
    while (i < size) {
        cout << cur[i]->val << " ";
        if (cur[i]->left != nullptr)
            cur.push_back(cur[i]->left);
        if (cur[i]->right != nullptr)
            cur.push_back(cur[i]->right);
        i++;
        size = cur.size();
    }
}

Node* Search(Node* root, int value) {
    if (root == nullptr)
        return nullptr;
    if (root->val == value)
        return root;
    if (value < root->val)
        return Search(root->left, value);
    return Search(root->right, value);
}

void insert(Node* &root, int value) {
    if (root == nullptr) {
        root = new Node(value);
        return;
    }
    if (value < root->val)
        insert(root->left, value);
    if (value > root->val)
        insert(root->right, value);
    return;
}

void Remove(Node* &root, int value) {
    if (root == nullptr)
        return;
    if (value < root->val)
        Remove(root->left, value);
    else if (value > root->val)
        Remove(root->right, value);
    else {
        if (root->left == nullptr) {
            Node* tmp = root->right;
            delete root;
            root = tmp;
        } else
        if (root->right == nullptr) {
            Node* tmp = root->left;
            delete root;
            root = tmp;
        } else {
            Node* tmp = root->right, *cur = tmp;
            while (cur->left != nullptr)
                cur = cur->left;
            cur->left = root->left;
            delete root;
            root = tmp;
        }
    }
}

Node* createTree(int a[], int n) {
    Node* root = nullptr;
    for (int i = 0; i < n; i++)
        insert(root, a[i]);
    return root;
}

void removeTree(Node* &root) {
    if (root == nullptr)
        return;
    removeTree(root->left);
    removeTree(root->right);
    delete root;
    root = nullptr;
}

int Height(Node* root) {
    if (root == nullptr)
        return -1;
    return 1 + max(Height(root->left), Height(root->right));
}

int countNode(Node* root) {
    if (root == nullptr)
        return 0;
    return 1 + countNode(root->left) + countNode(root->right);
}

int sumNode(Node* root) {
    if (root == nullptr)
        return 0;
    return root->val + sumNode(root->left) + sumNode(root->right);
}

int Level(Node* root, Node* p) {
    Node* cur = root;
    int level = 0;
    while (cur != nullptr && cur->val != p->val) {
        if (p->val < cur->val)
            cur = cur->left;
        else 
            cur = cur->right;
        level++;
    }
    return level;
}

int heightNode(Node*root, int value) {
    Node* node = Search(root, value);
    if (node == nullptr)
        return -1;
    return Height(root) - Level(root, node);
}

int countLeaf(Node* root) {
    if (root == nullptr)
        return 0;
    if (root->left == nullptr && root->right == nullptr)
        return 1;
    return countLeaf(root->left) + countLeaf(root->right);
}

int countLess(Node* root, int x) {
    if (root == nullptr)
        return 0;
    if (root->val == x)
        return countNode(root->left);
    if (root->val > x)
        return countLess(root->left, x);
    return 1 + countNode(root->left) + countLess(root->right, x);
}

int countGreater(Node* root, int x) {
    if (root == nullptr)
        return 0;
    if (root->val == x)
        return countNode(root->right);
    if (root->val < x)
        return countGreater(root->right, x);
    return 1 + countNode(root->right) + countGreater(root->left, x);
}

int findMin(Node* root) {
    if (root == nullptr)
        return INT_MAX;
    while (root->left != nullptr)
        root = root->left;
    return root->val;
}

int findMax(Node* root) {
    if (root == nullptr)
        return INT_MIN;
    while (root->right != nullptr)
        root = root->right;
    return root->val;
}

bool isBST(Node* root) {
    if (root == nullptr)
        return true;
    if (root->val <= findMax(root->left) || root->val >= findMin(root->right))
        return false;
    return isBST(root->left) && isBST(root->right);
}

bool isFullBST(Node* root) {
    if (root == nullptr)
        return true;
    if ((root->left == nullptr) ^ (root->right == nullptr))
        return false;
    if (root->val <= findMax(root->left) || root->val >= findMin(root->right))
        return false;
    return isFullBST(root->left) && isFullBST(root->right);
}

int main()
{
    int n = 9;
    int a[9] = {45, 15, 79, 10, 20, 55, 90, 12, 50};
    Node* root = createTree(a, n);
    Remove(root, 15);
    insert(root, 13);

    cout << "NLR: ";
    NLR(root);
    cout << "\n\n";

    cout << "LNR: ";
    LNR(root);
    cout << "\n\n";

    cout << "LRN: ";
    LRN(root);
    cout << "\n\n";

    cout << "Level Order: ";
    LevelOrder(root);
    cout << "\n\n";

    cout << "Height of binary search tree: ";
    cout << Height(root) << endl << endl;
    
    cout << "The number of nodes in tree: ";
    cout << countNode(root) << endl << endl;

    cout << "Sum of all nodes in tree: ";
    cout << sumNode(root) << endl << endl;

    int val = 90;
    cout << "Height of node " << val << ": ";
    cout << heightNode(root, val) << endl << endl;

    val = 90;
    cout << "Level of node " << val << ": ";
    cout << Level(root, Search(root, val)) << endl << endl;

    cout << "The number of leaf nodes in tree: ";
    cout << countLeaf(root) << endl << endl;

    val = 46;
    cout << "The number of nodes have value less than " << val << ": ";
    cout << countLess(root, val) << endl << endl;

    Node * node = Search(root, 10);
    node->left = new Node(9);
    Remove(root, 50);
    
    cout << isBST(root) << endl;
    cout << isFullBST(root);

    removeTree(root);
    
    return 0;
}