#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

void input(const string &fileName, int &n, int &m, int &s, int &t, vector<vector<int>> &adjList) {
    ifstream ifs(fileName);
    if (!ifs) {
        cout << "Cant open file!";
        ifs.close();
        return;
    }
    ifs >> n >> m >> s >> t;
    ifs.ignore();
    adjList.resize(n + 1);
    for (int i = 0; i < m; i++) {
        int u, v;
        ifs >> u >> v;
        ifs.ignore();
        adjList[u].push_back(v);
        adjList[v].push_back(u);
    }
    ifs.close();
}

void findPath(vector<int> trace, int s, int t) {
    if (t == s) {
        cout << s << " ";
        return;
    }
    findPath(trace, s, trace[t]);
    cout << t << " ";
}

void bfs(vector<vector<int>> adjList, int s, int t) {
    int n = adjList.size();
    vector<bool> visited(n + 1, false);
    vector<int> L(n + 1, -1);
    vector<int> trace(n + 1, -1);
    queue<int> q;
    q.push(s);
    L[s] = 0;
    trace[s] = s;
    while(!q.empty()) {
        int u = q.front();
        q.pop();
        visited[u] = true;
        for (auto v: adjList[u]) {
            if (!visited[v]) {
                q.push(v);
                L[v] = L[u] + 1;
                trace[v] = u;
                visited[v] = true;
            }
        }
        if (L[t] != -1)
            break;
    }
    if (L[t] == -1)
        cout << "Cant find path from " << s << " to " << t << endl;
    else {
        cout << L[t] << endl;
        findPath(trace, s, t);
    }
}

int main()
{
    int n, m, s, t;
    vector<vector<int>> adjList;
    input("input.txt", n, m, s, t, adjList);
    bfs(adjList, s, t);
    return 0;
}
