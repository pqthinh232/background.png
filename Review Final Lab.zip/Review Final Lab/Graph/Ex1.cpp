#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

vector<vector<int>> readMatrix(const string &fileName) {
    ifstream ifs(fileName);
    int n;
    ifs >> n;
    ifs.ignore();
    vector<vector<int>> matrix(n, vector<int>(n));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++)
            ifs >> matrix[i][j];
        ifs.ignore();
    }
    ifs.close();
    return matrix;
}

vector<vector<int>> convertToAdjList(vector<vector<int>> matrix) {
    int n = matrix.size();
    vector<vector<int>> adjlist(n);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            if (matrix[i][j] == 1)
                adjlist[i].push_back(j);
    return adjlist;
}

void printAdjList(vector<vector<int>> adjList) {
    int n = adjList.size();
    cout << n << endl;
    for (int i = 0; i < n; i++) {
        for (auto v : adjList[i])
            cout << v << " ";
        cout << endl;
    }
}

int main()
{
    vector<vector<int>> matrix = readMatrix("graph1.txt");
    vector<vector<int>> adjList = convertToAdjList(matrix);
    printAdjList(adjList);

    return 0;
}
