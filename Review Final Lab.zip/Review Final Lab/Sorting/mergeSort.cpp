#include <iostream>
#include <vector>

using namespace std;

void merge(vector<int> &a, vector<int> &aux, int l, int m, int r) {
    if (l >= r)
        return;
    for (int i = l; i <= r; i++)
        aux[i] = a[i];
    int i = l, j = m + 1, k = l;
    while (i <= m && j <= r) {
        if (aux[i] <= aux[j])
            a[k++] = aux[i++];
        else
            a[k++] = aux[j++];
    }
    while (i <= m)
        a[k++] = aux[i++];
    while (j <= r)
        a[k++] = aux[j++];
    return;
}

void mergeSort(vector<int> &a, vector<int> &aux, int l, int r) {
    if (l >= r)
        return;
    int m = (l + r) / 2;
    mergeSort(a, aux, l, m);
    mergeSort(a, aux, m + 1, r);
    merge(a, aux, l, m, r);
}

void mergeSort(vector<int> &a) {
    int n = a.size();
    vector<int> aux(n);
    mergeSort(a, aux, 0, n - 1);
}

void displayArray(vector<int> a) {
    for (auto v : a)
        cout << v << " ";
    cout << endl;
}

int main()
{
    vector<int> a{10,6,3,7,4,2,9,1,8,5};
    mergeSort(a);
    displayArray(a);

    return 0;
}