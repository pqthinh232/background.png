#include <iostream>
#include <vector>

using namespace std;

int partition(vector<int> &a, int left, int right) {
    int i = left - 1, j = right, v = a[right];
    for (;;) {
        while (a[++i] < v);
        while (a[--j] > v)
            if (j == left)
                break;
        if (i >= j)
            break;
        swap(a[i], a[j]);
    }
    swap(a[i], a[right]);
    return i;
}

void quickSort(vector<int> &a, int left, int right) {
    if (left >= right)
        return;
    int i = partition(a, left, right);
    quickSort(a, left, i - 1);
    quickSort(a, i + 1, right);
    return;
}

void quickSort(vector<int> &a) {
    quickSort(a, 0, a.size() - 1);
}

void displayArray(vector<int> a) {
    for (auto v : a)
        cout << v << " ";
    cout << endl;
}

int main()
{
    vector<int> a{10,6,3,7,4,2,9,1,8,5};
    quickSort(a);
    displayArray(a);

    return 0;
}