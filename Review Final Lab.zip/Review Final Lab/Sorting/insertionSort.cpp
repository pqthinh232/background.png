#include <iostream>
#include <vector>

using namespace std;

void insertionSort(vector<int> &a) {
    int n = a.size();
    for (int i = 1; i < n; i++) {
        int j = i, v = a[i];
        while (a[j - 1] > v) {
            a[j] = a[j - 1];
            j--;
        }
        a[j] = v;
    }
}

void displayArray(vector<int> a) {
    for (auto v : a)
        cout << v << " ";
    cout << endl;
}

int main()
{
    vector<int> a{10,6,3,7,4,2,9,1,8,5};
    insertionSort(a);
    displayArray(a);

    return 0;
}