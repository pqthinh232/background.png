#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int SIZE = 50;

struct Company {
    string name;
    string profit_tax;
    string address;
    Company() : name(""), profit_tax(""), address("") {}
};

vector<Company> ReadCompanyList(string file_name) {
    vector<Company> companies;
    ifstream ifs(file_name);
    string s;
    getline(ifs, s);
    while (!ifs.eof()) {
        Company company;
        getline(ifs, company.name, '|');
        if (company.name == "")
            break;
        getline(ifs, company.profit_tax, '|');
        getline(ifs, company.address);
        companies.push_back(company);
    }
    ifs.close();
    return companies;
}

long long HashString(string company_name) {
    unsigned long long m = 1000000000 + 9;
    int size = company_name.length();
    int start = size < 20 ? 0 : size - 20;
    unsigned long long sum = 0, p = 1;
    for (long long i = start; i < size; i++) {
        sum += (static_cast<int>(company_name[i]) * p);
        p *= 31;
    }
    return sum % m;
}

int linearProbing(long long hashValue, int i) {
    return (hashValue + i) % SIZE;
}

void Insert(Company* &hash_table, Company company) {
    int hashValue = HashString(company.name);
    for (int i = 0; i < SIZE; i++) {
        int idx = linearProbing(hashValue, i);
        if ((hash_table[idx]).name == "") {
            hash_table[idx] = company;
            return;
        }
    }
    cout << "Table is full\n";
}

Company* CreateHashTable(vector<Company> list_company) {
    Company* table = new Company[SIZE];
    int n = list_company.size();
    for (int i = 0; i < n; i++) {
        Company company = list_company[i];
        Insert(table, company);
    }
    return table;
}

Company* Search(Company* hash_table, string company_name) {
    long long hashValue = HashString(company_name);
    for (int i = 0; i < SIZE; i++) {
        int idx = linearProbing(hashValue, i);
        if ((hash_table[idx]).name == company_name) {
            return &hash_table[idx];
        }
    }
    return nullptr;
 }

void displayTable(Company* hash_table) {
    for (int i = 0; i < SIZE; i++) {
        cout << i << ". ";
        if (hash_table[i].name != "")
            cout << hash_table[i].name << "|" << hash_table[i].profit_tax << "|" << hash_table[i].address;
        cout << endl;
    }
}


int main()
{
    vector<Company> companies = ReadCompanyList("MST.txt");
    Company* table = CreateHashTable(companies);
    displayTable(table);
    Company* com = Search(table, "CONG TY CO PHAN THUONG MAI CHAU DUC PHAT");
    if (com == nullptr)
        cout << "Not Found\n";
    else 
        cout << com->name;
        
    return 0;
}