#include <iostream>
#include <vector>

using namespace std;

const int SIZE = 31;

struct Node {
    int val;
    bool occupied;

    Node() : val(-1), occupied(false) {};
    Node(int val) : val(val), occupied(true) {};
};

int hashFunc(int val){
    return val % SIZE;
}

int linearProbing(int hashValue, int i) {
    return (hashValue + i) % SIZE;
}

void insertTable(vector<Node> &table, int val){
    int hashValue = hashFunc(val);

    for (int i = 0; i < SIZE; i++) {
        int idx = linearProbing(hashValue, i);
        if (!table[idx].occupied) {
            table[idx] = Node(val);
            return;
        }
    }

    cout << "Table is full slot!\n";
}

void deleteKey(vector<Node> &table, int val){
    int hashValue = hashFunc(val);

    for (int i = 0; i < SIZE; i++) {
        int idx = linearProbing(hashValue, i);
        if (table[idx].occupied && table[idx].val == val) {
            table[idx] = Node();
            return;
        }
    }

    cout << "Value not found" << endl;
}

bool search(vector<Node> &table, int val){
    int hashValue = hashFunc(val);

    for (int i = 0; i < SIZE; i++) {
        int idx = linearProbing(hashValue, i);
        if (table[idx].occupied && table[idx].val == val)
            return true;
    }

    return false;
}

int main()
{

    return 0;
}
