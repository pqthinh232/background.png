#include <iostream>
#include <vector>

using namespace std;

const int SIZE = 31, PRIME = 7;

struct Node{
    int val;
    bool occupied;

    Node() : val(-1), occupied(false) {};
    Node(int val) : val(val), occupied(true) {};
};

int hashFunc1(int val){
    return val % SIZE;
}

int hashFunc2(int val){
    return PRIME - (val % PRIME);
}

int doubleHashingProbing(int hash1, int hash2, int i) {
    return (hash1 + i * hash2) % SIZE;
}

void insertTable(vector<Node> &table, int val){
    int hash1 = hashFunc1(val), hash2 = hashFunc2(val);

    for (int i = 0; i <= SIZE; i++) {
        int idx = doubleHashingProbing(hash1, hash2, i);
        if (!table[idx].occupied) {
            table[idx] = Node(val);
            return;
        }
    }

    cout << "Table is full slot!\n";
}

void deleteKey(vector<Node> &table, int val){
    int hash1 = hashFunc1(val), hash2 = hashFunc2(val);

    for (int i = 0; i <= SIZE; i++) {
        int idx = doubleHashingProbing(hash1, hash2, i);
        if (table[idx].occupied && table[idx].val == val) {
            table[idx] = Node();
            return;
        }
    }

    cout << "Value not found" << endl;
}

bool search(vector<Node> &table, int val){
    int hash1 = hashFunc1(val), hash2 = hashFunc2(val);

    for (int i = 0; i < SIZE; i++) {
        int idx = doubleHashingProbing(hash1, hash2, i);
        if (table[idx].occupied && table[idx].val == val)
            return true;
    }

    return false;
}

int main()
{

    return 0;
}
