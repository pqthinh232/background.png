#include <iostream>
#include <vector>

using namespace std;

const int SIZE = 31;

struct Node {
    int val;
    Node *next;

    Node (int val) : val(val), next(nullptr) {};
};

int hashFunc(int val) {
    return val % SIZE;
}

void insertList(Node *&root, int val) {
    if(root == nullptr) {
        Node *newNode = new Node(val);
        root = newNode;
        return;
    }

    insertList(root->next, val);
}

void insertTable(vector<Node*> &table, int val) {
    int idx = hashFunc(val);
    insertList(table[idx], val);
}

bool search(vector<Node*> &table, int val) {
    int idx = hashFunc(val);
    Node *temp = table[idx];

    while(temp != nullptr)
    {
        if(temp->val == val)
            return true;

        temp = temp->next;
    }

    return false;
}

int main()
{


    return 0;
}