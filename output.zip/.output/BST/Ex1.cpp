#include <iostream>
#include <fstream>

using namespace std;

struct Node {
    string name;
    Node *left, *right;
    Node(string str) : name(str), left(nullptr), right(nullptr) {}
};

Node* Search(Node *root, string name) {
    if (root == nullptr)
        return nullptr;
    if (root->name == name) 
        return root;
    Node* result = Search(root->left, name);
    if (result != nullptr)
        return result;
    return Search(root->right, name);
}

void insertNode(Node* &root, string parent, string child1, string child2) {
    Node* node1 = new Node(child1);
    Node* node2 = new Node(child2);
    if (root == nullptr) {
        root = new Node(parent);
        root->left = node1;
        root->right = node2;
    }   
    Node* node = Search(root, parent);
    node->left = node1;
    node->right = node2;
    return;
}

void createTree(Node* &root, string inputFile) {
    ifstream ifs;
    ifs.open(inputFile);
    if (!ifs) {
        cout << "Cant open file!";
        return;
    }
    int n;
    ifs >> n;
    ifs.ignore();
    for (int i = 0; i < n; i++) {
        char c;
        string parent, child1, child2, s;
        ifs >> c;
        getline(ifs, parent, ' ');
        ifs >> c;
        getline(ifs, child1, ' ');
        getline(ifs, child2, ')');
        ifs >> c;
        ifs.ignore();
        insertNode(root, parent, child1, child2);
    }
    ifs.close();
}

void NLR(Node*root) {
    if (root == nullptr)
        return;
    cout << root->name << " ";
    NLR(root->left);
    NLR(root->right);
}

void LNR(Node*root) {
    if (root == nullptr)
        return;
    LNR(root->left);
    cout << root->name << " ";
    LNR(root->right);
}

void LRN(Node*root) {
    if (root == nullptr)
        return;
    LRN(root->left);
    LRN(root->right);
    cout << root->name << " ";
}

int main()
{
    Node* root = nullptr;
    createTree(root, "input.txt");

    cout << "NLR: ";
    NLR(root);
    cout << endl;

    cout << "LNR: ";
    LNR(root);
    cout << endl;

    cout << "LRN: ";
    LRN(root);
    cout << endl;

    return 0;
}