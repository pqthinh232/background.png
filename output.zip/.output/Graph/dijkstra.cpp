#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

void input(const string &fileName, int &n, int &m, int &s, int &t, vector<vector<pair<int,int>>> &graph) {
    ifstream ifs(fileName);
    ifs >> n >> m >> s >> t;
    ifs.ignore();
    graph.resize(n + 1);
    for (int i = 0; i < m; i++) {
        int u, v, w;
        ifs >> u >> v >> w;
        ifs.ignore();
        graph[u].push_back({v, w});
        graph[v].push_back({u, w});
    }
    ifs.close();
}

void findPath(vector<int> trace, int s, int t) {
    if (s == t) {
        cout << s << " ";
        return;
    }
    findPath(trace, s, trace[t]);
    cout << t << " ";
}

void dijkstra(vector<vector<pair<int, int>>> graph, int s, int t) {
    int n = graph.size() - 1; // NHO TRU 1
    vector<bool> visited(n + 1, false);
    vector<int> L(n + 1, INT_MAX);
    vector<int> trace(n + 1);
    priority_queue<pair<int, int>, vector<pair<int,int>>, greater<pair<int, int>>> q;
    q.push({0, s});
    L[s] = 0;
    while (!q.empty()) {
        pair<int, int> top = q.top();
        q.pop();
        int u = top.second, kc = top.first;
        if (!visited[u]) {
            visited[u] = true;
            for (auto neighbor : graph[u]) {
                int v = neighbor.first, w = neighbor.second;
                if (L[v] > L[u] + w) {
                    L[v] = L[u] + w;
                    q.push({L[v], v});
                    trace[v] = u;
                }
            }
        }
    }
    //cout << L[t] << endl;
    //findPath(trace, s, t);
    for (int i = 1; i <= n; i++)
        cout << L[i] << " ";
}

int main()
{
    int n, m, s, t;
    vector<vector<pair<int,int>>> graph;
    input("input.txt", n, m, s, t, graph);
    dijkstra(graph, s, t);
    return 0;
}
