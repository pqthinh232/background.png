#include <iostream>
#include <fstream>
#include <queue>
#include <vector>

using namespace std;

void input(const string &fileName, int &n, int &m, int &c_lib, int &c_road, vector<vector<int>> &graph) {
    ifstream ifs(fileName);
    if (!ifs) {
        cout << "Cant open file!";
        ifs.close();
        return;
    }
    ifs >> n >> m >> c_lib >> c_road;
    ifs.ignore();
    graph.resize(n + 1);
    for (int i = 0; i < m; i++) {
        int u, v;
        ifs >> u >> v;
        ifs.ignore();
        graph[u].push_back(v);
        graph[v].push_back(u);
    }
    ifs.close();
}

void dfs(vector<vector<int>> graph, vector<bool> &visited, int city) {
    visited[city] = true;
    for (auto neighbor : graph[city])
        if (!visited[neighbor])
            dfs(graph, visited, neighbor);
}

void bfs(vector<vector<int>> graph, vector<bool> &visited, int city) {
    queue<int> q;
    q.push(city);
    visited[city] = true;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (auto neighbor: graph[u]) {
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                q.push(neighbor);
            }
        }
    }
}

int main()
{
    int n, m , c_lib, c_road;
    vector<vector<int>> graph;
    input("lab9.txt" ,n, m, c_lib, c_road, graph);
    vector<bool> visited(n + 1, false);
    if (c_lib <= c_road) {
        cout << c_lib * n << endl;
    } else {
        int cntLib = 0;
        for (int i = 1; i <= n; i++) {
            if (!visited[i]) {
                bfs(graph, visited, i);
                cntLib++;
            }
        }
        cout << cntLib * c_lib + (n - cntLib) * c_road;
    }
    return 0;
}
