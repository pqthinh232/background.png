#include <iostream>
#include <fstream>
#include <queue>
#include <vector>

using namespace std;

int dx[4] = {-1, 0, 1, 0};
int dy[4] = {0, 1, 0, -1};

void input(const string &fileName, int &m, int &n, vector<vector<char>> &graph) {
    ifstream ifs(fileName);
    if (!ifs) {
        cout << "Cant open file!";
        ifs.close();
        return;
    }
    ifs >> m >> n;
    graph.resize(m, vector<char>(n));
    ifs.ignore();
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++)
            ifs >> graph[i][j];
        ifs.ignore();
    }
    ifs.close();
}

int bfs(vector<vector<char>> &graph, int x, int y) {
    int m = graph.size(), n = graph[0].size();
    vector<vector<bool>> visited(m, vector<bool>(n, false));
    vector<vector<int>> L(m, vector<int>(n, INT_MAX));
    queue<pair<int, int>> q;
    q.push({x, y});
    L[x][y] = 0;
    visited[x][y] = true;
    while (!q.empty()) {
        pair<int, int> top = q.front();
        q.pop();
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                int x1 = top.first + dx[i];
                int y1 = top.second + dy[i];
                if (x1 >= 0 && x1 < m && y1 >= 0 && y1 < n && graph[x1][y1] != 'x' && !visited[x1][y1]) {
                    q.push({x1, y1});
                    L[x1][y1] = L[top.first][top.second] + 1;
                    visited[x1][y1] = true;
                    if (graph[x1][y1] == 'B')
                        return L[x1][y1];
                }
            }
        }
    }
    return -1;
}

void solve(int &m, int &n, vector<vector<char>> &graph) {
    int x = -1, y = -1;
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            if (graph[i][j] == 'A') {
                x = i; y = j;
                break;
            }
        }
        if (x != -1 && y != -1)
            break;
    }
    int ans = bfs(graph, x, y);
    if (ans == -1)
        cout << "Cant find the path from A to B!";
    else
        cout << ans;
}

int main()
{
    int m, n;
    vector<vector<char>> graph;
    input("input.txt", m, n, graph);
    solve(m, n, graph);
    return 0;
}
