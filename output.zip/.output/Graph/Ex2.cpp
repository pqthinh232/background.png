#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
using namespace std;

vector<vector<int>> readAdjList(const string &fileName) {
    ifstream ifs(fileName);
    int n;
    ifs >> n;
    ifs.ignore();
    vector<vector<int>> adjList(n);
    string s;
    for (int i = 0; i < n; i++) {
        getline(ifs, s);
        stringstream ss(s);
        int vertex;
        while (ss >> vertex) {
            adjList[i].push_back(vertex);
        }
    }
    ifs.close();
    return adjList;
}

vector<vector<int>> convertToAdjMatrix(vector<vector<int>> adjList) {
    int n = adjList.size();
    vector<vector<int>> adjMatrix(n, vector<int>(n, 0));
    for (int i = 0; i < n; i++)
        for (auto j : adjList[i])
            adjMatrix[i][j] = 1;
    return adjMatrix;
}

void printAdjMatrix(vector<vector<int>> adjMatrix) {
    cout << adjMatrix.size() << endl;
    for (auto v : adjMatrix) {
        for(auto value : v)
            cout << value << " ";
        cout << endl;
    }
}

int main()
{
    vector<vector<int>> adjList = readAdjList("graph2.txt");
    vector<vector<int>> adjMatrix = convertToAdjMatrix(adjList);
    printAdjMatrix(adjMatrix);
    return 0;
}
