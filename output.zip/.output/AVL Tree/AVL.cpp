#include <iostream>

using namespace std;

struct Node{
    int value;
    Node* left;
    Node* right;
    int height;
    Node(int val) : value(val), left(nullptr), right(nullptr), height(1) {}
};

int height(Node* root) {
    if (root == nullptr)
        return 0;
    return root->height;
}

Node* rotateLeft(Node* &root) {
    if (root == nullptr)
        return root;
    Node* newRoot = root->right;
    root->right = newRoot->left;
    newRoot->left = root;
    root->height = 1 + max(height(root->left), height(root->right));
    newRoot->height = 1 + max(height(newRoot->left), height(newRoot->right));
    return newRoot;
}

Node* rotateRight(Node* &root) {
    if (root == nullptr)
        return root;
    Node* newRoot = root->left;
    root->left = newRoot->right;
    newRoot->right = root;
    root->height = 1 + max(height(root->left), height(root->right));
    newRoot->height = 1 + max(height(newRoot->left), height(newRoot->right));
    return newRoot;
}

int getBalance(Node* root) {
    if (root == nullptr)
        return 0;
    return height(root->left) - height(root->right);
}

Node* balanceTree(Node* &root) {
    if (root == nullptr)
        return root;
    int balance = getBalance(root);
    if (balance > 1 && getBalance(root->left) >= 0)
        return rotateRight(root);
    if (balance < -1 && getBalance(root->right) <= 0)
        return rotateLeft(root);
    if (balance > 1 && getBalance(root->left) < 0) {
        root->left = rotateLeft(root->left);
        return rotateRight(root);
    }
    if (balance < -1 && getBalance(root->right) > 0) {
        root->right = rotateRight(root->right);
        return rotateLeft(root);
    }
    return root;
}

Node* insertNode(Node* &root, int val) {
    if (root == nullptr) {
        return new Node(val);
    }
    if (val == root->value)
        return root;
    if (val < root->value)
        root->left = insertNode(root->left, val);
    else
    if (val > root->value)
        root->right = insertNode(root->right, val);
    root->height = 1 + max(height(root->left), height(root->right));
    root = balanceTree(root);
    return root;
}

Node* deleteNode(Node* &root, int val){
    if (root == nullptr)
        return root;
    if (val < root->value)
        root->left = deleteNode(root->left, val);
    else
    if (val > root->value)
        root->right = deleteNode(root->right, val);
    else {
        if (root->left == nullptr && root->right == nullptr) {
            delete root;
            root = nullptr;
        } else
        if (root->left == nullptr) {
            Node* tmp = root;
            root = root->right;
            delete tmp;
        } else
        if (root->right == nullptr) {
            Node* tmp = root;
            root = root->left;
            delete tmp;
        } else {
            Node* cur = root->right;
            while (cur->left != nullptr)
                cur = cur->left;
            root->value = cur->value;
            root->right = deleteNode(root->right, cur->value);
        }
    }
    if (root == nullptr)
        return root;
    root->height = 1 + max(height(root->left), height(root->right));
    root = balanceTree(root);
    return root;
}

bool isAVL(Node* root) {
    if (root == nullptr)
        return true;
    int balanceVal = getBalance(root);
    if (balanceVal > 1 || balanceVal < -1)
        return false;
    return isAVL(root->left) && isAVL(root->right);
}

void NLR(Node* root) {
    if (root == nullptr)
        return;
    cout << root->value << " ";
    NLR(root->left);
    NLR(root->right);
}

void destroy(Node* &root) {
    if (root == nullptr)
        return;
    destroy(root->left);
    destroy(root->right);
    delete root;
    root = nullptr;
}

int main()
{
    Node *root = nullptr;

    root = insertNode(root, 9);
    root = insertNode(root, 5);
    root = insertNode(root, 10);
    root = insertNode(root, 0);
    root = insertNode(root, 6);
    root = insertNode(root, 11);
    root = insertNode(root, -1);
    root = insertNode(root, 1);
    root = insertNode(root, 2);

    cout << "Preorder traversal of the "
            "constructed AVL tree is \n";
    NLR(root);

    root = deleteNode(root, 10);

    cout << "\nPreorder traversal after"
            " deletion of 10 \n";
    NLR(root);

    destroy(root);

    return 0;
}