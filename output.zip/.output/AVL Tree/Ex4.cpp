#include <iostream>

using namespace std;

struct Node {
    int val;
    Node* left;
    Node* right;
    Node(int value) : val(value), left(nullptr), right(nullptr) {}
};

void insert(Node* &root, int value) {
    if (root == nullptr) {
        Node* node = new Node(value);
        root = node;
        return;
    }
    if (root->val == value)
        return;
    if (value < root->val)
        insert(root->left, value);
    else    
        insert(root->right, value);
}

int height(Node* root) {
    if (root == nullptr)
        return -1;
    return 1 + max(height(root->left), height(root->right));
}

Node* createTree(int a[], int n) {
    Node* root = nullptr;
    for (int i = 0; i < n; i++)
        insert(root, a[i]);
    return root;
}

bool isAVL(Node* root) {
    if (root == nullptr)
        return true;
    int temp = height(root->left) - height(root->right);
    if (temp > 1 || temp < -1)
        return false;
    return isAVL(root->left) && isAVL(root->right);
}

Node* Search(Node* root, int val) {
    if (root == nullptr)
        return nullptr;
    if (root->val == val)
        return root;
    if (val < root->val)
        return Search(root->left, val);
    else    
        return Search(root->right, val);
}

Node* lowestCommonAncestor(Node* root, Node* p, Node* q) {
    if (root == nullptr)
        return nullptr;
    if (root->val == p->val || root->val == q->val)
        return root;
    if (Search(root->left, p->val) != nullptr && Search(root->left, q->val) != nullptr)
        return lowestCommonAncestor(root->left, p, q);
    if (Search(root->right, p->val) != nullptr && Search(root->right, q->val) != nullptr)
        return lowestCommonAncestor(root->right, p, q);
    return root;
}

void destroy(Node* &root) {
    if (root == nullptr)
        return;
    destroy(root->left);
    destroy(root->right);
    delete root;
    root = nullptr;
}

int main()
{
    int a[] = {5, 2, 0, 1, 4, 3, 8, 7, 6, 9, 10};
    int n = sizeof(a) / sizeof(int);

    Node* root = createTree(a, n);

    if (!isAVL(root)) {
        cout << "It's not AVL tree!\n";
        return 1;
    }

    Node* p = Search(root, 6);
    Node* q = Search(root, 8);
    
    Node * ancestor = lowestCommonAncestor(root, p, q);
    cout << "Lowest common ancestor for node " << p->val << " and node " << q->val << " is " << ancestor->val << endl;
    destroy(root);
    return 0;
}