#include <iostream>
#include <vector>

using namespace std;

// void insertionSort(vector<int> &a) {
//     int n = a.size();
//     for (int i = 1; i < n; i++) {
//         int j, v = a[i];
//         if (v % 2 == 0) {
//             int prev = i;
//             for (j = i - 1; j >= 0; j--) {
//                 if (a[j] % 2 == 0) {
//                     if (a[j] > v) {
//                         a[prev] = a[j];
//                         prev = j;
//                     } else  {
//                         a[prev] = v;
//                         break;
//                     }
//                 }
//             }
//             if (j == -1)
//                 a[0] = v;
//         } else {
//             int prev = i;
//             for (j = i - 1; j >= 0; j--) {
//                 if (a[j] % 2 == 1) {
//                     if (a[j] < v) {
//                         a[prev] = a[j];
//                         prev = j;
//                     } else  {
//                         a[prev] = v;
//                         break;
//                     }
//                 }
//             }
//             if (j == -1)
//                 a[0] = v;
//         }
//     }
// }

void insertionSort(vector<int> &a) {
    int n = a.size();
    for (int i = 1; i < n; i++) {
        int j, v = a[i];
        if (v % 2 == 0) {
            int prev = i;
            for (j = i - 1; j >= 0; j--) {
                if (a[j] % 2 == 0 && a[j] > v) {
                    a[prev] = a[j];
                    prev = j;
                }
            }
            a[prev] = v;
        } else {
            int prev = i;
            for (j = i - 1; j >= 0; j--) {
                if (a[j] % 2 == 1 && a[j] < v) {
                    a[prev] = a[j];
                    prev = j;
                }
            }
            a[prev] = v;
        }
    }
}

void displayArray(vector<int> a) {
    for (auto v : a)
        cout << v << " ";
    cout << endl;
}

int main()
{
    vector<int> a{1, 2, 4, 7, 15, 18, 8, 9, 11};
    insertionSort(a);
    displayArray(a);

    return 0;
}