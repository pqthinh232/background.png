class Solution {
public:
    vector<vector<int>> pathSum(TreeNode* root, int targetSum) {
        vector<vector<int>> ans;
        if (root == nullptr)
            return ans;
        if (root->left == nullptr && root->right == nullptr)
            if (root->val == targetSum)
                return {{root->val}};
            else
                return {};
        vector<vector<int>> leftSide = pathSum(root->left, targetSum - root->val);
        vector<vector<int>> rightSide = pathSum(root->right, targetSum - root->val);
        for (auto v : leftSide) {
            vector<int> arr;
            arr.push_back(root->val);
            for (auto val : v)
                arr.push_back(val);
            ans.push_back(arr);
        }
        for (auto v : rightSide) {
            vector<int> arr;
            arr.push_back(root->val);
            for (auto val : v)
                arr.push_back(val);
            ans.push_back(arr);
        }
        return ans;
    }
};