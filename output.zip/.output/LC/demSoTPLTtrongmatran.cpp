class Solution {

private:
    void loang(vector<vector<char>>& grid, vector<vector<bool>> &visited, int i, int j) {
        int m = grid.size(), n = grid[0].size();
        visited[i][j] = true;
        if (j + 1 < n && !visited[i][j + 1] && grid[i][j + 1] == '1')
            loang(grid, visited, i, j + 1);
        if (j - 1 >= 0 && !visited[i][j - 1] && grid[i][j - 1] == '1')
            loang(grid, visited, i, j - 1);
        if (i + 1 < m && !visited[i + 1][j] && grid[i + 1][j] == '1')
            loang(grid, visited, i + 1, j);
        if (i - 1 >= 0 && !visited[i - 1][j] && grid[i - 1][j] == '1')
            loang(grid, visited, i - 1, j);
    }

public:
    int numIslands(vector<vector<char>>& grid) {
        int m = grid.size(), n = grid[0].size();
        vector<vector<bool>> visited(m, vector<bool>(n, false));
        int ans = 0;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++)
                if (!visited[i][j] && grid[i][j] == '1') {
                    loang(grid, visited, i, j);
                    ans++;
                }
        }
        return ans;
    }
};