class Solution {
public:
    int sumNumbers(TreeNode* root) {
        return sumNumbers(root, 0);
    }

private:
    int sumNumbers(TreeNode* root, int num) {
        if (root == nullptr)
            return 0;
        num = num * 10 + root->val;
        if (root->left == nullptr && root->right == nullptr)    
            return num;
        return sumNumbers(root->left, num) + sumNumbers(root->right, num);
    }
};