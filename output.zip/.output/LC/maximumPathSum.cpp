class Solution {
public:
    int maxPathSum(TreeNode* root) {
        if(root == nullptr)
            return 0;
        int ans = INT_MIN;
        dfs(root, ans);
        return ans;
    }

private:
    int dfs(TreeNode* root, int &ans) {
        if (root == nullptr)
            return 0;
        int l = max(dfs(root->left, ans), 0);
        int r = max(dfs(root->right, ans), 0);
        int sum = root->val + l + r;
        ans = max(sum, ans);
        return root->val + max(l, r);
    }
};