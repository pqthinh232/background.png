class Solution {

private:

    int countNode(TreeNode* root) {
        if (root == nullptr)
            return 0;
        return 1 + countNode(root->left) + countNode(root->right);
    }

public:
    int kthSmallest(TreeNode* root, int k) {
        int kth = countNode(root->left) + 1;
        while (kth != k && root != nullptr) {
            if (kth  < k) {
                root = root->right;
                kth += countNode(root->left) + 1;
            }
            else {
                root = root->left;
                kth -= countNode(root->right) + 1;
            }
        }
        return root->val;
    }
};