#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int partition(vector<int> &a, int left, int right) {
    int i = left - 1, j = right, v = a[right];
    for (;;) {
        while (a[++i] < v);
        while (a[--j] > v)
            if (j == left)
                break;
        if (i >= j)
            break;
        swap(a[i], a[j]);
    }
    swap(a[i], a[right]);
    return i;
}

void quickSort(vector<int> &a, int left, int right) {
    if (left >= right)
        return;
    int i = partition(a, left, right);
    quickSort(a, left, i - 1);
    quickSort(a, i + 1, right);
    return;
}

void quickSort(vector<int> &a) {
    quickSort(a, 0, a.size() - 1);
}

int linearSearch(vector<int> a, int value) {
    int i = 0, n = a.size();
    while (i < n) {
        if (a[i] == value)
            return i;
        i++;
    }
    return -1;
}

int linearSearchWithSentinel(vector<int> a, int value) {
    int i = 0;
    a.push_back(value);
    while (true) {
        if (a[i] == value)
            break;
        i++;
    }
    a.pop_back();
    if (i == a.size()) 
        return -1;
    else    
        return i;
}

int binarySearch(vector<int> a, int value) {
    int l = 0, r = a.size() - 1;
    while (l <= r) {
        int m = (l + r) / 2;
        if (a[m] == value)
            return m;
        if (value < a[m])
            r = m - 1;
        else    
            l = m + 1;
    }
    return -1;
}

int main(int argc, char* argv[])
{
    int algorithm = stoi(argv[1]);
    int x = stoi(argv[2]);
    string inputFile = argv[3];
    string outputFile = argv[4];
    int n;
    vector<int> a;
    ifstream ifs;
    ifs.open(inputFile);
    ifs >> n;
    for (int i = 0; i < n; i++) {
        int temp;
        ifs >> temp;
        a.push_back(temp);
    }
    ifs.close();
    ofstream ofs;
    ofs.open(outputFile);
    if (algorithm == 1)
        ofs << linearSearch(a, x);
    else if (algorithm == 2)
        ofs << linearSearchWithSentinel(a, x);
    else if (algorithm == 3) {
        quickSort(a);
        for (auto v : a)
            ofs << v << " ";
        ofs << endl;
        ofs << binarySearch(a, x);
    } else {
        ofs << "Invalid algorithm!";
    }
    ofs.close();

    return 0;
}